This is the supplemental material for "Repairing Man-Made Meshes via Visual Driven Global Optimization with Minimum Intrusion", ACM Trans. Graph. 38, Siggraph Asia 2019. 

The package contains:

 -MeshFiles/: mesh files for several examples shown in the paper.
 -ComparisonModels/: mesh models for comparison with previous methods.
 -supp.pdf: the document supplementing the paper text with more details.

