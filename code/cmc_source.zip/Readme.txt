This is a demo implementation of the surface modeling algorithm presented in the paper "Robust Modeling of Constant Mean Curvature Surfaces".

"test.cpp" provides a test driver of the source code.

To use the modeling algorithm in your project, please include the header file "fast_rdt.h".