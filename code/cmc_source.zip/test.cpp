// test.cpp : test driver.
//

#include <iostream>

#include "fast_rdt.h"

int main(int argc, char* argv[])
{
	

	CMC::EdgeMesh emesh ("simple_6gon.obj");
	emesh.mark_boundary();

	CMC::CMC_Evolver evolver;
	evolver.set_mesh(&emesh);
	evolver.set_volume_weight(1);
	
	evolver.cmc_qnewton(10,1);
	//evolver.cmc_lloyd(10,1);

	emesh.save_obj("simple_6gon_copy.obj");

	char c;
	std::cin.get(c);
	return 0;
}

